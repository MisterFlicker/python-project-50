import json as json_global


def lets_json(diff) -> str:
    return json_global.dumps(diff)
